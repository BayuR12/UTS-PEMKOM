package Form;

public class Session {
    public static int id_user;
    public static String nama;
    public static String username;
    public static String email;
    public static String role;
    
}
